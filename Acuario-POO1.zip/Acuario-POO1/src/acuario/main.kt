package acuario

fun construirAcuario() {
    val acuario1 = Acuario()
    acuario1.imprimirTamaño()
    val acuario2 = Acuario(ancho = 25)
    acuario2.imprimirTamaño()
    val acuario3 = Acuario(alto = 35, largo = 110)
    acuario3.imprimirTamaño()
    val acuario4 = Acuario(ancho = 25, alto = 35, largo = 110)
    acuario4.imprimirTamaño()



    val acuario6 = Acuario(numeroDePeces = 29)
    acuario6.imprimirTamaño()


    val acuario7 = Acuario(numeroDePeces = 29)
    acuario7.imprimirTamaño()
    acuario7.volumen = 70
    acuario7.imprimirTamaño()


    val acuario8 = Acuario(largo = 25, ancho = 25 ,alto = 40)
    acuario8.imprimirTamaño()

    val miAcuario = Acuario(ancho = 25, largo = 25, alto = 40)
    miAcuario.imprimirTamaño()
    val miTorre = TanqueTorre(diametro = 25, alto = 40)
    miTorre.imprimirTamaño()
}
fun main() {
    construirAcuario(

    )

}

